import pygame
import random
import math
import logging
import sys
import os
from pygame import gfxdraw

# Setup logging
logging.basicConfig(level=logging.DEBUG, filename='connect4.log', filemode='w',
                    format='%(asctime)s - %(levelname)s - %(message)s')

# Initialize Pygame
try:
    pygame.init()
    # Initialize the mixer for sound effects
    pygame.mixer.init()
    logging.info("Pygame and mixer initialized successfully")
except Exception as e:
    logging.error(f"Failed to initialize Pygame: {e}")
    raise

# Constants
ROW_COUNT = 6
COLUMN_COUNT = 7
SQUARE_SIZE = 100
RADIUS = int(SQUARE_SIZE / 2 - 5)
WIDTH = COLUMN_COUNT * SQUARE_SIZE
HEIGHT = (ROW_COUNT + 1) * SQUARE_SIZE
FPS = 60

# Colors
BLUE = (0, 102, 204)
DARK_BLUE = (0, 51, 153)
BLACK = (0, 0, 0)
RED = (220, 20, 60)
BRIGHT_RED = (255, 50, 50)
YELLOW = (255, 215, 0)
BRIGHT_YELLOW = (255, 255, 0)
WHITE = (255, 255, 255)
LIGHT_GRAY = (200, 200, 200)
GREEN = (50, 205, 50)
TRANSPARENT = (0, 0, 0, 0)

# Screen setup
try:
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Connect 4")
    clock = pygame.time.Clock()
    logging.info("Screen and clock initialized")
except Exception as e:
    logging.error(f"Failed to set up screen: {e}")
    raise

# Font setup
try:
    title_font = pygame.font.SysFont("comicsans", 72) or pygame.font.Font(None, 72)
    font = pygame.font.SysFont("comicsans", 40) or pygame.font.Font(None, 40)
    small_font = pygame.font.SysFont("comicsans", 30) or pygame.font.Font(None, 30)
    logging.info("Fonts loaded")
except Exception as e:
    logging.error(f"Failed to load font: {e}")
    title_font = pygame.font.Font(None, 72)
    font = pygame.font.Font(None, 40)
    small_font = pygame.font.Font(None, 30)

# Sound effects setup
sounds = {}
sound_enabled = True
sound_volume = 0.7  # Default volume (0.0 to 1.0)

def load_sounds():
    """Load all sound effects"""
    global sounds
    try:
        # Create sounds directory if it doesn't exist
        if not os.path.exists("sounds"):
            os.makedirs("sounds")
            logging.info("Created sounds directory")
        
        # Define sound file paths
        sound_files = {
            "drop": "sounds/drop.wav",
            "win": "sounds/win.wav",
            "draw": "sounds/draw.wav",
            "click": "sounds/click.wav",
            "hover": "sounds/hover.wav",
            "menu_music": "sounds/menu_music.wav",
        }
        
        # Create placeholder sound files if they don't exist
        for sound_name, sound_path in sound_files.items():
            if not os.path.exists(sound_path):
                create_placeholder_sound(sound_name, sound_path)
        
        # Load sounds
        for sound_name, sound_path in sound_files.items():
            try:
                sounds[sound_name] = pygame.mixer.Sound(sound_path)
                sounds[sound_name].set_volume(sound_volume)
                logging.info(f"Loaded sound: {sound_name}")
            except Exception as e:
                logging.error(f"Failed to load sound {sound_name}: {e}")
                # Create a silent sound as fallback
                sounds[sound_name] = pygame.mixer.Sound(buffer=bytearray(44100))  # 1 second of silence
        
        logging.info("Sound effects loaded")
    except Exception as e:
        logging.error(f"Failed to load sounds: {e}")
        sound_enabled = False

def create_placeholder_sound(sound_name, sound_path):
    """Create a placeholder sound file with appropriate characteristics"""
    try:
        import wave
        import struct
        
        # Sound parameters
        duration = 1.0  # seconds
        sample_rate = 44100
        amplitude = 4096
        
        # Create different sounds based on type
        if sound_name == "drop":
            # Short dropping sound
            duration = 0.3
            frequency = 440  # A4 note
            decay = 0.1
        elif sound_name == "win":
            # Triumphant sound
            duration = 1.0
            frequency = 880  # A5 note
            decay = 0.01
        elif sound_name == "draw":
            # Neutral sound
            duration = 0.7
            frequency = 330  # E4 note
            decay = 0.05
        elif sound_name == "click":
            # Short click
            duration = 0.1
            frequency = 1000
            decay = 0.2
        elif sound_name == "hover":
            # Very short, high-pitched sound
            duration = 0.05
            frequency = 2000
            decay = 0.5
        elif sound_name == "menu_music":
            # Simple melody
            duration = 3.0
            frequency = 440
            decay = 0.001
        
        # Generate sound data
        num_samples = int(duration * sample_rate)
        sound_data = bytearray()
        
        for i in range(num_samples):
            t = i / sample_rate
            damping = math.exp(-t / decay)
            value = int(amplitude * math.sin(2 * math.pi * frequency * t) * damping)
            packed_value = struct.pack('h', value)
            sound_data.extend(packed_value)
            sound_data.extend(packed_value)  # Duplicate for stereo
        
        # Write to WAV file
        with wave.open(sound_path, 'wb') as wav_file:
            wav_file.setnchannels(2)  # Stereo
            wav_file.setsampwidth(2)  # 2 bytes per sample
            wav_file.setframerate(sample_rate)
            wav_file.writeframes(sound_data)
        
        logging.info(f"Created placeholder sound: {sound_name}")
    except Exception as e:
        logging.error(f"Failed to create placeholder sound {sound_name}: {e}")

def play_sound(sound_name):
    """Play a sound effect if sound is enabled"""
    if sound_enabled and sound_name in sounds:
        try:
            sounds[sound_name].play()
        except Exception as e:
            logging.error(f"Failed to play sound {sound_name}: {e}")

def set_volume(volume):
    """Set volume for all sounds (0.0 to 1.0)"""
    global sound_volume
    sound_volume = max(0.0, min(1.0, volume))
    for sound in sounds.values():
        sound.set_volume(sound_volume)

# Game state
board = None
game_over = False
turn = 0
difficulty = None
running = True
game_state = "welcome"  # welcome, playing, game_over
animation_pieces = []  # For drop animation
hover_col = 0
hover_alpha = 0
hover_direction = 1
button_hover = None
winning_pieces = []  # Store positions of winning pieces
win_animation_time = 0  # Timer for win animation
game_result = None  # "player_win", "ai_win", "draw"
last_hover = None  # Track last hovered button for hover sound

# Button class for UI
class Button:
    def __init__(self, x, y, width, height, text, color, hover_color, text_color=WHITE):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.color = color
        self.hover_color = hover_color
        self.text_color = text_color
        self.hovered = False
        
    def draw(self, surface):
        color = self.hover_color if self.hovered else self.color
        pygame.draw.rect(surface, color, self.rect, border_radius=10)
        pygame.draw.rect(surface, WHITE, self.rect, 3, border_radius=10)
        
        text_surf = font.render(self.text, True, self.text_color)
        text_rect = text_surf.get_rect(center=self.rect.center)
        surface.blit(text_surf, text_rect)
        
    def is_hovered(self, pos):
        return self.rect.collidepoint(pos)

# Animation piece class
class AnimationPiece:
    def __init__(self, col, final_row, piece):
        self.col = col
        self.y = SQUARE_SIZE // 2
        self.final_y = HEIGHT - (final_row * SQUARE_SIZE + SQUARE_SIZE // 2)
        self.piece = piece
        self.velocity = 0
        self.gravity = 0.7
        self.bounces = 0
        self.max_bounces = 2
        self.done = False
        self.sound_played = False
        
    def update(self):
        if self.done:
            return True
            
        self.velocity += self.gravity
        self.y += self.velocity
        
        if self.y >= self.final_y and self.bounces < self.max_bounces:
            self.y = self.final_y
            self.velocity = -self.velocity * 0.6
            self.bounces += 1
            
            # Play drop sound on first bounce
            if self.bounces == 1 and not self.sound_played:
                play_sound("drop")
                self.sound_played = True
                
        elif self.y >= self.final_y:
            self.y = self.final_y
            self.done = True
            
        return self.done
        
    def draw(self, surface):
        color = RED if self.piece == 1 else YELLOW
        pygame.draw.circle(surface, color, (self.col * SQUARE_SIZE + SQUARE_SIZE // 2, int(self.y)), RADIUS)
        # Add shine effect
        pygame.draw.circle(surface, (255, 255, 255, 100), 
                          (self.col * SQUARE_SIZE + SQUARE_SIZE // 2 - 15, int(self.y) - 15), 
                          RADIUS // 3)

# Particle class for win animation
class Particle:
    def __init__(self, x, y, color):
        self.x = x
        self.y = y
        self.color = color
        self.size = random.randint(2, 6)
        self.velocity_x = random.uniform(-2, 2)
        self.velocity_y = random.uniform(-4, -1)
        self.gravity = 0.1
        self.life = 100
        
    def update(self):
        self.velocity_y += self.gravity
        self.x += self.velocity_x
        self.y += self.velocity_y
        self.life -= 1
        return self.life <= 0
        
    def draw(self, surface):
        alpha = min(255, self.life * 2.55)
        color_with_alpha = (self.color[0], self.color[1], self.color[2], alpha)
        s = pygame.Surface((self.size, self.size), pygame.SRCALPHA)
        pygame.draw.circle(s, color_with_alpha, (self.size // 2, self.size // 2), self.size // 2)
        surface.blit(s, (int(self.x), int(self.y)))

def create_board():
    return [[0 for _ in range(COLUMN_COUNT)] for _ in range(ROW_COUNT)]

def drop_piece(board, row, col, piece):
    global animation_pieces
    board[row][col] = piece
    # Add animation
    animation_pieces.append(AnimationPiece(col, row, piece))

def is_valid_location(board, col):
    return 0 <= col < COLUMN_COUNT and board[0][col] == 0

def get_next_open_row(board, col):
    for r in range(ROW_COUNT - 1, -1, -1):
        if board[r][col] == 0:
            return r
    return None

def is_board_full(board):
    return all(board[0][c] != 0 for c in range(COLUMN_COUNT))

def check_winning_move(board, piece):
    global winning_pieces
    winning_pieces = []
    
    # Check horizontal
    for r in range(ROW_COUNT):
        for c in range(COLUMN_COUNT - 3):
            if all(board[r][c + i] == piece for i in range(4)):
                winning_pieces = [(r, c + i) for i in range(4)]
                return True
    
    # Check vertical
    for c in range(COLUMN_COUNT):
        for r in range(ROW_COUNT - 3):
            if all(board[r + i][c] == piece for i in range(4)):
                winning_pieces = [(r + i, c) for i in range(4)]
                return True
    
    # Check positively sloped diagonals
    for c in range(COLUMN_COUNT - 3):
        for r in range(ROW_COUNT - 3):
            if all(board[r + i][c + i] == piece for i in range(4)):
                winning_pieces = [(r + i, c + i) for i in range(4)]
                return True
    
    # Check negatively sloped diagonals
    for c in range(COLUMN_COUNT - 3):
        for r in range(3, ROW_COUNT):
            if all(board[r - i][c + i] == piece for i in range(4)):
                winning_pieces = [(r - i, c + i) for i in range(4)]
                return True
    
    return False

def evaluate_window(window, piece):
    score = 0
    opp_piece = 1 if piece == 2 else 2
    if window.count(piece) == 4:
        score += 100
    elif window.count(piece) == 3 and window.count(0) == 1:
        score += 5
    elif window.count(piece) == 2 and window.count(0) == 2:
        score += 2
    if window.count(opp_piece) == 3 and window.count(0) == 1:
        score -= 4
    return score

def score_position(board, piece):
    score = 0
    center_array = [board[r][COLUMN_COUNT // 2] for r in range(ROW_COUNT)]
    center_count = center_array.count(piece)
    score += center_count * 3
    for r in range(ROW_COUNT):
        for c in range(COLUMN_COUNT - 3):
            window = [board[r][c + i] for i in range(4)]
            score += evaluate_window(window, piece)
    for c in range(COLUMN_COUNT):
        for r in range(ROW_COUNT - 3):
            window = [board[r + i][c] for i in range(4)]
            score += evaluate_window(window, piece)
    for r in range(ROW_COUNT - 3):
        for c in range(COLUMN_COUNT - 3):
            window = [board[r + i][c + i] for i in range(4)]
            score += evaluate_window(window, piece)
    for r in range(3, ROW_COUNT):
        for c in range(COLUMN_COUNT - 3):
            window = [board[r - i][c + i] for i in range(4)]
            score += evaluate_window(window, piece)
    return score

def minimax(board, depth, alpha, beta, maximizing_player):
    valid_locations = [c for c in range(COLUMN_COUNT) if is_valid_location(board, c)]
    is_terminal = len(valid_locations) == 0 or check_winning_move(board, 1) or check_winning_move(board, 2)
    if depth == 0 or is_terminal:
        if is_terminal:
            if check_winning_move(board, 2):
                return (None, 1000000)
            elif check_winning_move(board, 1):
                return (None, -1000000)
            else:  # Board full
                return (None, 0)
        else:
            return (None, score_position(board, 2))
    if maximizing_player:
        value = -math.inf
        column = random.choice(valid_locations) if valid_locations else None
        for col in valid_locations:
            row = get_next_open_row(board, col)
            b_copy = [row[:] for row in board]
            # Don't add animation for simulation
            b_copy[row][col] = 2
            new_score = minimax(b_copy, depth - 1, alpha, beta, False)[1]
            if new_score > value:
                value = new_score
                column = col
            alpha = max(alpha, value)
            if alpha >= beta:
                break
        return column, value
    else:
        value = math.inf
        column = random.choice(valid_locations) if valid_locations else None
        for col in valid_locations:
            row = get_next_open_row(board, col)
            b_copy = [row[:] for row in board]
            # Don't add animation for simulation
            b_copy[row][col] = 1
            new_score = minimax(b_copy, depth - 1, alpha, beta, True)[1]
            if new_score < value:
                value = new_score
                column = col
            beta = min(beta, value)
            if alpha >= beta:
                break
        return column, value

def draw_gradient_background():
    try:
        for y in range(HEIGHT):
            r = 30 + int((y / HEIGHT) * 20)
            g = 30 + int((y / HEIGHT) * 50)
            b = 100 + int((y / HEIGHT) * 100)
            pygame.draw.line(screen, (r, g, b), (0, y), (WIDTH, y))
        logging.info("Gradient background drawn")
    except Exception as e:
        logging.error(f"Failed to draw gradient background: {e}")

def draw_board_background():
    try:
        # Draw board background
        pygame.draw.rect(screen, DARK_BLUE, (0, SQUARE_SIZE, WIDTH, HEIGHT - SQUARE_SIZE))
        
        # Draw grid slots
        for c in range(COLUMN_COUNT):
            for r in range(ROW_COUNT):
                pygame.draw.circle(
                    screen, 
                    BLACK, 
                    (c * SQUARE_SIZE + SQUARE_SIZE // 2, (r + 1) * SQUARE_SIZE + SQUARE_SIZE // 2), 
                    RADIUS
                )
        
        # Draw board frame
        pygame.draw.rect(screen, BLUE, (0, SQUARE_SIZE, WIDTH, HEIGHT - SQUARE_SIZE), 5)
        for c in range(1, COLUMN_COUNT):
            pygame.draw.line(
                screen, 
                BLUE, 
                (c * SQUARE_SIZE, SQUARE_SIZE), 
                (c * SQUARE_SIZE, HEIGHT), 
                3
            )
        
        logging.info("Board background drawn")
    except Exception as e:
        logging.error(f"Failed to draw board background: {e}")

def draw_pieces(board):
    global animation_pieces, winning_pieces, win_animation_time
    try:
        for c in range(COLUMN_COUNT):
            for r in range(ROW_COUNT):
                if board[r][c] == 0:
                    continue
                    
                # Determine if this piece is part of the winning combination
                is_winning_piece = (r, c) in winning_pieces
                
                # Determine color based on piece type and if it's a winning piece
                if board[r][c] == 1:
                    # Player piece (red)
                    if is_winning_piece:
                        # Pulsate winning pieces
                        pulse = math.sin(win_animation_time * 0.1) * 0.5 + 0.5
                        color = (
                            int(RED[0] + (BRIGHT_RED[0] - RED[0]) * pulse),
                            int(RED[1] + (BRIGHT_RED[1] - RED[1]) * pulse),
                            int(RED[2] + (BRIGHT_RED[2] - RED[2]) * pulse)
                        )
                        # Draw highlight ring
                        pygame.draw.circle(
                            screen, 
                            GREEN, 
                            (c * SQUARE_SIZE + SQUARE_SIZE // 2, HEIGHT - (r * SQUARE_SIZE + SQUARE_SIZE // 2)), 
                            RADIUS + 5,
                            3
                        )
                    else:
                        color = RED
                        
                    pygame.draw.circle(
                        screen, 
                        color, 
                        (c * SQUARE_SIZE + SQUARE_SIZE // 2, HEIGHT - (r * SQUARE_SIZE + SQUARE_SIZE // 2)), 
                        RADIUS
                    )
                    # Add shine effect
                    pygame.draw.circle(
                        screen, 
                        (255, 255, 255, 100), 
                        (c * SQUARE_SIZE + SQUARE_SIZE // 2 - 15, HEIGHT - (r * SQUARE_SIZE + SQUARE_SIZE // 2) - 15), 
                        RADIUS // 3
                    )
                elif board[r][c] == 2:
                    # AI piece (yellow)
                    if is_winning_piece:
                        # Pulsate winning pieces
                        pulse = math.sin(win_animation_time * 0.1) * 0.5 + 0.5
                        color = (
                            int(YELLOW[0] + (BRIGHT_YELLOW[0] - YELLOW[0]) * pulse),
                            int(YELLOW[1] + (BRIGHT_YELLOW[1] - YELLOW[1]) * pulse),
                            int(YELLOW[2] + (BRIGHT_YELLOW[2] - YELLOW[2]) * pulse)
                        )
                        # Draw highlight ring
                        pygame.draw.circle(
                            screen, 
                            GREEN, 
                            (c * SQUARE_SIZE + SQUARE_SIZE // 2, HEIGHT - (r * SQUARE_SIZE + SQUARE_SIZE // 2)), 
                            RADIUS + 5,
                            3
                        )
                    else:
                        color = YELLOW
                        
                    pygame.draw.circle(
                        screen, 
                        color, 
                        (c * SQUARE_SIZE + SQUARE_SIZE // 2, HEIGHT - (r * SQUARE_SIZE + SQUARE_SIZE // 2)), 
                        RADIUS
                    )
                    # Add shine effect
                    pygame.draw.circle(
                        screen, 
                        (255, 255, 255, 100), 
                        (c * SQUARE_SIZE + SQUARE_SIZE // 2 - 15, HEIGHT - (r * SQUARE_SIZE + SQUARE_SIZE // 2) - 15), 
                        RADIUS // 3
                    )
        
        # Draw animation pieces
        for piece in animation_pieces:
            piece.draw(screen)
            
        # Update win animation time
        if winning_pieces:
            win_animation_time += 1
            
        logging.info("Pieces drawn")
    except Exception as e:
        logging.error(f"Failed to draw pieces: {e}")

def draw_hover_piece(col):
    if 0 <= col < COLUMN_COUNT and game_state == "playing" and turn == 0 and not game_over:
        # Create a surface with per-pixel alpha
        s = pygame.Surface((RADIUS * 2, RADIUS * 2), pygame.SRCALPHA)
        # Draw the circle with alpha
        pygame.draw.circle(s, (RED[0], RED[1], RED[2], hover_alpha), (RADIUS, RADIUS), RADIUS)
        # Blit the surface onto the screen
        screen.blit(s, (col * SQUARE_SIZE + SQUARE_SIZE // 2 - RADIUS, SQUARE_SIZE // 2 - RADIUS))

def draw_welcome_screen():
    try:
        # Draw background
        draw_gradient_background()
        
        # Draw title
        title = title_font.render("CONNECT 4", True, WHITE)
        screen.blit(title, (WIDTH // 2 - title.get_width() // 2, HEIGHT // 4 - title.get_height() // 2))
        
        # Draw board image
        board_preview_width = WIDTH // 2
        board_preview_height = HEIGHT // 3
        board_preview_x = WIDTH // 2 - board_preview_width // 2
        board_preview_y = HEIGHT // 2 - board_preview_height // 2
        
        # Draw a mini board as preview
        pygame.draw.rect(screen, DARK_BLUE, (board_preview_x, board_preview_y, board_preview_width, board_preview_height))
        mini_square = min(board_preview_width // COLUMN_COUNT, board_preview_height // ROW_COUNT)
        mini_radius = mini_square // 2 - 2
        
        for c in range(COLUMN_COUNT):
            for r in range(ROW_COUNT):
                pygame.draw.circle(
                    screen, 
                    BLACK, 
                    (board_preview_x + c * mini_square + mini_square // 2, 
                     board_preview_y + r * mini_square + mini_square // 2), 
                    mini_radius
                )
        
        # Add some sample pieces to the preview
        sample_board = [
            [0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 1, 0, 0, 0],
            [0, 0, 1, 2, 0, 0, 0],
            [0, 0, 2, 1, 1, 0, 0],
            [0, 2, 2, 1, 2, 0, 0]
        ]
        
        for c in range(COLUMN_COUNT):
            for r in range(ROW_COUNT):
                if sample_board[r][c] == 1:
                    pygame.draw.circle(
                        screen, 
                        RED, 
                        (board_preview_x + c * mini_square + mini_square // 2, 
                         board_preview_y + r * mini_square + mini_square // 2), 
                        mini_radius
                    )
                elif sample_board[r][c] == 2:
                    pygame.draw.circle(
                        screen, 
                        YELLOW, 
                        (board_preview_x + c * mini_square + mini_square // 2, 
                         board_preview_y + r * mini_square + mini_square // 2), 
                        mini_radius
                    )
        
        # Draw buttons
        play_button.draw(screen)
        difficulty_button.draw(screen)
        sound_button.draw(screen)
        
        # Draw current difficulty (top-left)
        diff_text = "Current Difficulty: "
        if difficulty is None:
            diff_text += "Not Selected"
        elif difficulty == 2:
            diff_text += "Easy"
        elif difficulty == 4:
            diff_text += "Medium"
        elif difficulty == 6:
            diff_text += "Hard"
            
        diff_surf = small_font.render(diff_text, True, WHITE)
        screen.blit(diff_surf, (20, 20))  # Position in top-left
        
        # Draw sound status (top-right)
        sound_text = f"Sound: {'ON' if sound_enabled else 'OFF'}"
        sound_surf = small_font.render(sound_text, True, WHITE)
        screen.blit(sound_surf, (WIDTH - sound_surf.get_width() - 20, 20))  # Position in top-right
        
        pygame.display.update()
        logging.info("Welcome screen drawn")
    except Exception as e:
        logging.error(f"Failed to draw welcome screen: {e}")

def draw_game_ui():
    try:
        pygame.draw.rect(screen, BLACK, (0, 0, WIDTH, SQUARE_SIZE))
        
        if not game_over:
            if turn == 0:
                text = font.render("Player's Turn", True, RED)
            else:
                text = font.render("AI's Turn", True, YELLOW)
            screen.blit(text, (WIDTH // 2 - text.get_width() // 2, SQUARE_SIZE // 2 - text.get_height() // 2))
            
            # Draw back button
            back_button.draw(screen)
        else:
            # Draw game result with animation
            if game_result == "player_win":
                pulse = math.sin(win_animation_time * 0.05) * 0.2 + 1.0
                text = font.render("Player Wins!", True, RED)
                text = pygame.transform.scale(text, (int(text.get_width() * pulse), int(text.get_height() * pulse)))
            elif game_result == "ai_win":
                pulse = math.sin(win_animation_time * 0.05) * 0.2 + 1.0
                text = font.render("AI Wins!", True, YELLOW)
                text = pygame.transform.scale(text, (int(text.get_width() * pulse), int(text.get_height() * pulse)))
            else:  # draw
                text = font.render("Draw!", True, WHITE)
                
            screen.blit(text, (WIDTH // 2 - text.get_width() // 2, SQUARE_SIZE // 2 - text.get_height() // 2))
            
            # Draw restart and menu buttons
            restart_button.draw(screen)
            menu_button.draw(screen)
            
        logging.info("Game UI drawn")
    except Exception as e:
        logging.error(f"Failed to draw game UI: {e}")

def draw_difficulty_screen():
    try:
        # Draw background
        draw_gradient_background()
        
        # Draw title
        title = title_font.render("SELECT DIFFICULTY", True, WHITE)
        screen.blit(title, (WIDTH // 2 - title.get_width() // 2, HEIGHT // 4 - title.get_height() // 2))
        
        # Draw difficulty buttons
        easy_button.draw(screen)
        medium_button.draw(screen)
        hard_button.draw(screen)
        back_to_menu_button.draw(screen)
        
        pygame.display.update()
        logging.info("Difficulty screen drawn")
    except Exception as e:
        logging.error(f"Failed to draw difficulty screen: {e}")

def update_animations():
    global animation_pieces, hover_alpha, hover_direction
    # Update animation pieces
    completed = []
    for i, piece in enumerate(animation_pieces):
        if piece.update():
            completed.append(i)
    
    # Remove completed animations (in reverse order to avoid index issues)
    for i in sorted(completed, reverse=True):
        animation_pieces.pop(i)
    
    # Update hover animation
    hover_alpha += hover_direction * 5
    if hover_alpha >= 200:
        hover_alpha = 200
        hover_direction = -1
    elif hover_alpha <= 50:
        hover_alpha = 50
        hover_direction = 1

def setup():
    global board, game_over, turn, difficulty, running, game_state, animation_pieces
    global winning_pieces, win_animation_time, game_result
    board = create_board()
    game_over = False
    turn = 0
    if difficulty is None:
        difficulty = 4  # Default to medium if not set
    running = True
    game_state = "welcome"
    animation_pieces = []
    winning_pieces = []
    win_animation_time = 0
    game_result = None
    logging.info("Game setup completed")
    
    # Load sounds
    load_sounds()

# Create buttons
button_width = 200
button_height = 60
button_y_spacing = 80

# Welcome screen buttons
play_button = Button(
    WIDTH // 2 - button_width // 2,
    HEIGHT * 3 // 4 - button_height // 2 - button_y_spacing,
    button_width,
    button_height,
    "PLAY",
    BLUE,
    DARK_BLUE
)

difficulty_button = Button(
    WIDTH // 2 - button_width // 2,
    HEIGHT * 3 // 4 - button_height // 2,
    button_width,
    button_height,
    "DIFFICULTY",
    BLUE,
    DARK_BLUE
)

sound_button = Button(
    WIDTH // 2 - button_width // 2,
    HEIGHT * 3 // 4 - button_height // 2 + button_y_spacing,
    button_width,
    button_height,
    "TOGGLE SOUND",
    BLUE,
    DARK_BLUE
)

# Difficulty screen buttons
easy_button = Button(
    WIDTH // 2 - button_width // 2,
    HEIGHT // 2 - button_height // 2 - button_y_spacing,
    button_width,
    button_height,
    "EASY",
    BLUE,
    DARK_BLUE
)

medium_button = Button(
    WIDTH // 2 - button_width // 2,
    HEIGHT // 2 - button_height // 2,
    button_width,
    button_height,
    "MEDIUM",
    BLUE,
    DARK_BLUE
)

hard_button = Button(
    WIDTH // 2 - button_width // 2,
    HEIGHT // 2 - button_height // 2 + button_y_spacing,
    button_width,
    button_height,
    "HARD",
    BLUE,
    DARK_BLUE
)

back_to_menu_button = Button(
    WIDTH // 2 - button_width // 2,
    HEIGHT // 2 - button_height // 2 + button_y_spacing * 2,
    button_width,
    button_height,
    "BACK",
    (150, 50, 50),
    (200, 50, 50)
)

# Game screen buttons
back_button = Button(
    10,
    10,
    100,
    40,
    "MENU",
    (150, 50, 50),
    (200, 50, 50),
    WHITE
)

restart_button = Button(
    WIDTH // 2 - button_width // 2 - button_width // 2 - 20,
    SQUARE_SIZE // 2 + 40,
    button_width // 2,
    button_height // 2,
    "RESTART",
    BLUE,
    DARK_BLUE
)

menu_button = Button(
    WIDTH // 2 + 20,
    SQUARE_SIZE // 2 + 40,
    button_width // 2,
    button_height // 2,
    "MENU",
    (150, 50, 50),
    (200, 50, 50)
)

def check_game_over(board, last_piece):
    """Check if the game is over and set the appropriate game state"""
    global game_over, game_result
    
    # Check for win
    if check_winning_move(board, last_piece):
        game_over = True
        if last_piece == 1:
            game_result = "player_win"
            play_sound("win")
            logging.info("Player wins")
        else:
            game_result = "ai_win"
            play_sound("win")
            logging.info("AI wins")
        return True
    
    # Check for draw
    if is_board_full(board):
        game_over = True
        game_result = "draw"
        play_sound("draw")
        logging.info("Game is a draw")
        return True
        
    return False

def check_button_hover(current_hover, buttons_dict):
    """Check if button hover state changed and play sound if needed"""
    global last_hover
    
    # Find which button is currently hovered
    current_button = None
    for name, button in buttons_dict.items():
        if button.hovered:
            current_button = name
            break
    
    # If hover changed, play sound
    if current_button != last_hover and current_button is not None:
        play_sound("hover")
    
    last_hover = current_button

def main():
    global game_over, turn, difficulty, running, game_state, hover_col, button_hover, animation_pieces
    global winning_pieces, win_animation_time, game_result, sound_enabled, last_hover
    setup()
    
    while running:
        # Get mouse position for button hover effects
        mouse_pos = pygame.mouse.get_pos()
        
        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                logging.info("Quit event received")
                
            elif event.type == pygame.MOUSEMOTION:
                # Update button hover states
                if game_state == "welcome":
                    play_button.hovered = play_button.is_hovered(mouse_pos)
                    difficulty_button.hovered = difficulty_button.is_hovered(mouse_pos)
                    sound_button.hovered = sound_button.is_hovered(mouse_pos)
                    
                    # Check for hover sound
                    welcome_buttons = {
                        "play": play_button,
                        "difficulty": difficulty_button,
                        "sound": sound_button
                    }
                    check_button_hover(button_hover, welcome_buttons)
                    
                    button_hover = "play" if play_button.hovered else "difficulty" if difficulty_button.hovered else "sound" if sound_button.hovered else None
                    
                elif game_state == "difficulty":
                    easy_button.hovered = easy_button.is_hovered(mouse_pos)
                    medium_button.hovered = medium_button.is_hovered(mouse_pos)
                    hard_button.hovered = hard_button.is_hovered(mouse_pos)
                    back_to_menu_button.hovered = back_to_menu_button.is_hovered(mouse_pos)
                    
                    # Check for hover sound
                    difficulty_buttons = {
                        "easy": easy_button,
                        "medium": medium_button,
                        "hard": hard_button,
                        "back": back_to_menu_button
                    }
                    check_button_hover(button_hover, difficulty_buttons)
                    
                    button_hover = "easy" if easy_button.hovered else "medium" if medium_button.hovered else "hard" if hard_button.hovered else "back" if back_to_menu_button.hovered else None
                    
                elif game_state == "playing":
                    back_button.hovered = back_button.is_hovered(mouse_pos)
                    
                    if game_over:
                        restart_button.hovered = restart_button.is_hovered(mouse_pos)
                        menu_button.hovered = menu_button.is_hovered(mouse_pos)
                        
                        # Check for hover sound
                        game_over_buttons = {
                            "back": back_button,
                            "restart": restart_button,
                            "menu": menu_button
                        }
                        check_button_hover(button_hover, game_over_buttons)
                    else:
                        # Check for hover sound
                        playing_buttons = {
                            "back": back_button
                        }
                        check_button_hover(button_hover, playing_buttons)
                    
                    # Update hover column for player piece
                    if turn == 0 and not game_over:
                        hover_col = event.pos[0] // SQUARE_SIZE
                
            elif event.type == pygame.MOUSEBUTTONDOWN:
                # Handle button clicks
                if game_state == "welcome":
                    if play_button.is_hovered(mouse_pos):
                        play_sound("click")
                        if difficulty is None:
                            difficulty = 4  # Default to medium
                        game_state = "playing"
                        board = create_board()
                        game_over = False
                        turn = 0
                        animation_pieces = []  # Reset animations
                        winning_pieces = []    # Reset winning pieces
                        win_animation_time = 0 # Reset animation time
                        game_result = None     # Reset game result
                        logging.info("Starting game")
                    elif difficulty_button.is_hovered(mouse_pos):
                        play_sound("click")
                        game_state = "difficulty"
                        logging.info("Opening difficulty screen")
                    elif sound_button.is_hovered(mouse_pos):
                        play_sound("click")
                        sound_enabled = not sound_enabled
                        logging.info(f"Sound toggled: {sound_enabled}")
                        
                elif game_state == "difficulty":
                    if easy_button.is_hovered(mouse_pos):
                        play_sound("click")
                        difficulty = 2
                        game_state = "welcome"
                        logging.info("Difficulty set to Easy")
                    elif medium_button.is_hovered(mouse_pos):
                        play_sound("click")
                        difficulty = 4
                        game_state = "welcome"
                        logging.info("Difficulty set to Medium")
                    elif hard_button.is_hovered(mouse_pos):
                        play_sound("click")
                        difficulty = 6
                        game_state = "welcome"
                        logging.info("Difficulty set to Hard")
                    elif back_to_menu_button.is_hovered(mouse_pos):
                        play_sound("click")
                        game_state = "welcome"
                        logging.info("Returning to welcome screen")
                        
                elif game_state == "playing":
                    if back_button.is_hovered(mouse_pos):
                        play_sound("click")
                        game_state = "welcome"
                        logging.info("Returning to welcome screen")
                    elif game_over:
                        if restart_button.is_hovered(mouse_pos):
                            play_sound("click")
                            board = create_board()
                            game_over = False
                            turn = 0
                            animation_pieces = []
                            winning_pieces = []
                            win_animation_time = 0
                            game_result = None
                            logging.info("Game restarted")
                        elif menu_button.is_hovered(mouse_pos):
                            play_sound("click")
                            game_state = "welcome"
                            logging.info("Returning to welcome screen")
                    elif turn == 0:
                        col = event.pos[0] // SQUARE_SIZE
                        if is_valid_location(board, col):
                            row = get_next_open_row(board, col)
                            drop_piece(board, row, col, 1)
                            
                            # Check for game over after player move
                            check_game_over(board, 1)
                            
                            if not game_over:
                                turn = 1
                                logging.info(f"Player dropped piece in column {col}")
        
        # Update animations
        update_animations()
        
        # AI move
        if game_state == "playing" and turn == 1 and not game_over and not animation_pieces:
            col, _ = minimax(board, difficulty, -math.inf, math.inf, True)
            if col is None or not is_valid_location(board, col):
                game_over = True
                game_result = "draw"
                play_sound("draw")
                logging.info("No valid moves for AI, game is a draw")
            else:
                row = get_next_open_row(board, col)
                drop_piece(board, row, col, 2)
                
                # Check for game over after AI move
                check_game_over(board, 2)
                
                if not game_over:
                    turn = 0
                    logging.info(f"AI dropped piece in column {col}")
        
        # Draw current screen
        if game_state == "welcome":
            draw_welcome_screen()
        elif game_state == "difficulty":
            draw_difficulty_screen()
        elif game_state == "playing":
            draw_gradient_background()
            draw_board_background()
            draw_pieces(board)
            draw_hover_piece(hover_col)
            draw_game_ui()
            pygame.display.update()
        
        # Cap the frame rate
        clock.tick(FPS)
    
    pygame.quit()
    logging.info("Pygame quit")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logging.error(f"Main loop failed: {e}")
        pygame.quit()
        raise
